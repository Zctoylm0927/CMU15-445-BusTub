show tables;
create table tb(s int, a int, b float, c char(16));
create table tb2(x int, y float, z char(16), s int);
show tables;
desc tb;
drop table tb;
show tables;
drop table tb2;
show tables;
#