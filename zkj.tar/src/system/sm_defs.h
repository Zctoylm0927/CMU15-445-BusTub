#pragma once

#include "defs.h"
#include <string>

static const std::string DB_META_NAME = "db.meta";
